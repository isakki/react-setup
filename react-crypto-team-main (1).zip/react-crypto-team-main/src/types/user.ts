export interface UserDataProps {
  id: number
  username: string
  email: string
  phone: string
  image: string
}