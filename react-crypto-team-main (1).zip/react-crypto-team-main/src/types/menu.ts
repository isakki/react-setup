export interface publicRouteProps {
  home: string,
  about: string,
  contact: string,
  services: string,
  login: string,
  register: string,
} 