export const isAuthenticated = true
export const isAdmin = false
