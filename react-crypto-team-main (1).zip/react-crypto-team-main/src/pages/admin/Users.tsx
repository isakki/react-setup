const Users = () => {
  return (
    <div>Users</div>
  )
}

export default Users